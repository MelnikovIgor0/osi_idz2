#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <string.h>
#include <signal.h>
#include <time.h>
#include <stdlib.h>

sem_t *sem1, *sem2, *sem3;
char sm[] = "sharedmemory";

void vendor(sem_t *sem, int* queue, int id) {
    printf("Vendor with ID: %d and process ID: %d started\n", id, getpid());
    while (queue[0] == 0) {
        if (queue[id]) {
            printf("Vendor with ID: %d and process ID: %d started to serve the buyer with ID: %d\n", id, getpid(), queue[id]);
            sleep(1 + rand() % 2);
            printf("Vendor with ID: %d and process ID: %d finished serving the buyer with ID: %d\n", id, getpid(), queue[id]);
            queue[id] = 0;
        } else {
            sleep(1);
        }
    }
    printf("Vendor with ID: %d and process ID: %d finished\n", id, getpid());
}

void buyer(int id, int* queue, sem_t *sem1, sem_t *sem2, sem_t *sem3) {
    ++queue[4];
    printf("Buyer with ID: %d and process ID: %d appeared\n", id, getpid());
    int current_vendor = id % 3;
    if (current_vendor == 0) {
        while (1) {
            if (queue[1] == 0) {
                printf("Buyer with ID: %d and process ID: %d gone to vendor 1\n", id, getpid());
                queue[1] = id;
                break;
            } else {
                sleep(1);
            }
        }
        while (queue[1]) { }
    } else if (current_vendor == 1) {
        while (1) {
            if (queue[2] == 0) {
                printf("Buyer with ID: %d and process ID: %d gone to vendor 2\n", id, getpid());
                queue[2] = id;
                break;
            } else {
                sleep(1);
            }
        }
        while (queue[2]) { }
    } else {
        while (1) {
            if (queue[3] == 0) {
                printf("Buyer with ID: %d and process ID: %d gone to vendor 3\n", id, getpid());
                queue[3] = id;
                break;
            } else {
                sleep(1);
            }
        }
        while (queue[3]) { }
    }
    printf("Buyer with ID: %d and process ID: %d disappeared\n", id, getpid());
    --queue[4];
    if (queue[4] == 0) {
        queue[0] = 1;
    }
}

void init_buyers(int number_buyers, int *queue, sem_t *sem1, sem_t *sem2, sem_t *sem3) {
    if (number_buyers == 0) {
        return;
    }
    if (fork()) {
        buyer(number_buyers, queue, sem1, sem2, sem3);
    } else {
        init_buyers(number_buyers - 1, queue, sem1, sem2, sem3);
    }
}

void init_vendors(int number_vendors, int *queue, sem_t *sem1, sem_t *sem2, sem_t *sem3) {
    if (number_vendors == 0) {
        return;
    }
    if (!fork()) {
        if (number_vendors == 3) {
            vendor(sem3, queue, 3);
        } else if (number_vendors == 2) {
            vendor(sem2, queue, 2);
        } else {
            vendor(sem1, queue, 1);
        }
    } else {
        init_vendors(number_vendors - 1, queue, sem1, sem2, sem3);
    }
}

void dispose_objects() {
    shm_unlink(sm);
    sem_close(sem1);
    sem_close(sem2);
    sem_close(sem3);
}

int main(int argc, char **argv) {
    struct sigaction action;
    action.sa_handler = dispose_objects;
    sigaction(SIGTERM, &action, NULL);

    srand(time(NULL));
    int *queue;
    int n, shm_size = 100;
    scanf("%d", &n);

    int shm = shm_open(sm, O_RDWR | O_CREAT, 0777);
    ftruncate(shm, shm_size);
    queue = mmap(0, shm_size, PROT_WRITE|PROT_READ, MAP_SHARED, shm, 0);
    
    queue[0] = 0;
    queue[1] = 0;
    queue[2] = 0;
    queue[3] = 0;
    queue[4] = 0;

    sem1 = sem_open("sem1", 0);
    sem2 = sem_open("sem2", 0);
    sem3 = sem_open("sem3", 0);
    
    if (fork() == 0) {
        init_buyers(n, queue, sem1, sem2, sem3);
    } else {
        init_vendors(3, queue, sem1, sem2, sem3);
    }

    dispose_objects();
    return 0;
}
